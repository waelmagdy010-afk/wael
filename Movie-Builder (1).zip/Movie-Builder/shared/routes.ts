import { z } from 'zod';
import { insertMovieSchema, movies, scenes } from './schema';

export const api = {
  movies: {
    create: {
      method: 'POST' as const,
      path: '/api/movies',
      input: insertMovieSchema,
      responses: {
        201: z.custom<typeof movies.$inferSelect>(),
        500: z.object({ message: z.string() }),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/movies',
      responses: {
        200: z.array(z.custom<typeof movies.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/movies/:id',
      responses: {
        200: z.custom<typeof movies.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
    getScenes: {
      method: 'GET' as const,
      path: '/api/movies/:id/scenes',
      responses: {
        200: z.array(z.custom<typeof scenes.$inferSelect>()),
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
