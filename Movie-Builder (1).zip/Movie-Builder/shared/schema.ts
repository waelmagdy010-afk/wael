import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  script: jsonb("script").$type<Array<{
    order: number;
    narration: string;
    imagePrompt: string;
  }>>(),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  videoUrl: text("video_url"),
  error: text("error"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const scenes = pgTable("scenes", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id").notNull(),
  order: integer("order").notNull(),
  narration: text("narration").notNull(),
  imagePrompt: text("image_prompt").notNull(),
  imageUrl: text("image_url"),
  audioUrl: text("audio_url"),
  videoUrl: text("video_url"), // Intermediate video segment
  status: text("status").default("pending"),
});

export const insertMovieSchema = createInsertSchema(movies).pick({
  prompt: true,
});

export type Movie = typeof movies.$inferSelect;
export type InsertMovie = z.infer<typeof insertMovieSchema>;
export type Scene = typeof scenes.$inferSelect;

export type CreateMovieRequest = InsertMovie;
