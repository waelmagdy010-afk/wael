## Packages
framer-motion | Page transitions and sleek animations
lucide-react | Iconography for the cinematic interface
date-fns | Formatting dates for movie history

## Notes
Backend Status Workflow: pending -> processing -> completed / failed
Video Player: Standard HTML5 <video> tag is sufficient for MP4 playback
Theme: Dark mode default (cinematic)
