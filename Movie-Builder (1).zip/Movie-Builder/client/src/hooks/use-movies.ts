import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertMovie } from "@shared/schema";

// GET /api/movies - List recent movies
export function useMovies() {
  return useQuery({
    queryKey: [api.movies.list.path],
    queryFn: async () => {
      const res = await fetch(api.movies.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch movies");
      return api.movies.list.responses[200].parse(await res.json());
    },
  });
}

// GET /api/movies/:id - Get single movie details
export function useMovie(id: number) {
  return useQuery({
    queryKey: [api.movies.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.movies.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch movie details");
      return api.movies.get.responses[200].parse(await res.json());
    },
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      // Poll if processing or pending
      return status === "pending" || status === "processing" ? 3000 : false;
    },
  });
}

// GET /api/movies/:id/scenes - Get scenes for a movie
export function useMovieScenes(movieId: number) {
  return useQuery({
    queryKey: [api.movies.getScenes.path, movieId],
    queryFn: async () => {
      const url = buildUrl(api.movies.getScenes.path, { id: movieId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch scenes");
      return api.movies.getScenes.responses[200].parse(await res.json());
    },
    // Poll more frequently for scenes as they generate
    refetchInterval: 2000, 
  });
}

// POST /api/movies - Create new movie
export function useCreateMovie() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertMovie) => {
      const validated = api.movies.create.input.parse(data);
      const res = await fetch(api.movies.create.path, {
        method: api.movies.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create movie");
      }
      return api.movies.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.movies.list.path] });
    },
  });
}
