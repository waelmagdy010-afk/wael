import { Link } from "wouter";
import { motion } from "framer-motion";
import { Play, Clock, AlertCircle } from "lucide-react";
import { type Movie } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface MovieCardProps {
  movie: Movie;
  index: number;
}

export function MovieCard({ movie, index }: MovieCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <span className="bg-green-500/20 text-green-400 border border-green-500/30 px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider">Ready</span>;
      case "failed":
        return <span className="bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider">Failed</span>;
      default:
        return <span className="bg-primary/20 text-primary border border-primary/30 px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider animate-pulse">Processing</span>;
    }
  };

  return (
    <Link href={`/movies/${movie.id}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1 }}
        className="group relative aspect-[2/3] rounded-xl overflow-hidden bg-card border border-white/5 cursor-pointer hover:border-primary/50 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/20 hover:-translate-y-2"
      >
        {/* Thumbnail or Placeholder */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent z-10" />
        
        {/* Dynamic Abstract Background if no image */}
        <div className="absolute inset-0 bg-secondary/50 group-hover:scale-105 transition-transform duration-700">
             {/* Use Lucide Icon as placeholder art */}
            <div className="absolute inset-0 flex items-center justify-center opacity-10 group-hover:opacity-20 transition-opacity">
               <Play className="w-32 h-32" />
            </div>
        </div>

        {/* Content Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-5 z-20">
            <div className="flex items-center justify-between mb-2">
                 {getStatusBadge(movie.status)}
                 {movie.createdAt && (
                    <span className="text-xs text-white/50 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDistanceToNow(new Date(movie.createdAt), { addSuffix: true })}
                    </span>
                 )}
            </div>
            
            <h3 className="font-display font-bold text-lg text-white leading-tight line-clamp-2 group-hover:text-primary transition-colors">
                {movie.prompt}
            </h3>
        </div>

        {/* Play Button Overlay on Hover */}
        <div className="absolute inset-0 z-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40 backdrop-blur-[2px]">
            <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center shadow-lg shadow-primary/40 transform scale-50 group-hover:scale-100 transition-transform duration-300">
                <Play className="w-6 h-6 text-white ml-1" fill="currentColor" />
            </div>
        </div>
      </motion.div>
    </Link>
  );
}
