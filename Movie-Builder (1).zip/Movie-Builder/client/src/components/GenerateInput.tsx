import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { useCreateMovie } from "@/hooks/use-movies";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export function GenerateInput() {
  const [prompt, setPrompt] = useState("");
  const createMovie = useCreateMovie();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    try {
      const movie = await createMovie.mutateAsync({ prompt });
      toast({
        title: "Production Started",
        description: "Your movie idea has been sent to the studio.",
      });
      setLocation(`/movies/${movie.id}`);
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative max-w-2xl mx-auto w-full group">
      <div className="absolute -inset-1 bg-gradient-to-r from-primary via-purple-500 to-blue-500 rounded-2xl blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200" />
      
      <div className="relative flex items-center bg-card border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="A cyberpunk detective solves a mystery in 2077..."
          className="flex-1 bg-transparent px-6 py-5 text-lg text-white placeholder:text-muted-foreground focus:outline-none font-medium"
          disabled={createMovie.isPending}
        />
        
        <button
          type="submit"
          disabled={createMovie.isPending || !prompt.trim()}
          className="mr-2 px-6 py-3 rounded-xl bg-primary hover:bg-primary/90 text-white font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-lg shadow-primary/20"
        >
          {createMovie.isPending ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Creating...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>Generate</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
}
