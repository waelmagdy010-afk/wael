import { Layout } from "@/components/Layout";
import { GenerateInput } from "@/components/GenerateInput";
import { MovieCard } from "@/components/MovieCard";
import { useMovies } from "@/hooks/use-movies";
import { Loader2, Film } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: movies, isLoading } = useMovies();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.03] z-0 pointer-events-none" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-full bg-primary/10 blur-[120px] rounded-full z-0 pointer-events-none" />
        
        <div className="container relative z-10 mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="font-display text-5xl md:text-7xl font-bold mb-6 tracking-tight">
              Turn Your Imagination Into <br />
              <span className="text-primary text-shadow-glow">Cinematic Reality</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed">
              Describe your story, and our AI Director will script, visualize, voice, and edit a complete short film for you in minutes.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <GenerateInput />
          </motion.div>
        </div>
      </section>

      {/* Recent Productions */}
      <section className="py-16 bg-gradient-to-b from-transparent to-black/20">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-10">
            <h2 className="font-display text-2xl font-bold flex items-center gap-3">
              <Film className="w-6 h-6 text-primary" />
              Recent Productions
            </h2>
            <div className="h-px flex-1 bg-gradient-to-r from-white/10 to-transparent ml-6" />
          </div>

          {isLoading ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-10 h-10 text-primary animate-spin" />
            </div>
          ) : movies && movies.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
              {movies.map((movie, idx) => (
                <MovieCard key={movie.id} movie={movie} index={idx} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-card/30 rounded-3xl border border-white/5 border-dashed">
              <p className="text-muted-foreground text-lg">No movies created yet. Be the first director!</p>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}
