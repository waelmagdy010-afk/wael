import { useEffect, useRef } from "react";
import { useRoute } from "wouter";
import { Layout } from "@/components/Layout";
import { useMovie, useMovieScenes } from "@/hooks/use-movies";
import { Loader2, CheckCircle2, AlertCircle, Film, ImageIcon, Mic, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

export default function MovieDetails() {
  const [, params] = useRoute("/movies/:id");
  const id = parseInt(params?.id || "0");
  const { data: movie, isLoading: loadingMovie, error: movieError } = useMovie(id);
  const { data: scenes } = useMovieScenes(id);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Auto-play video when it becomes ready
  useEffect(() => {
    if (movie?.status === "completed" && movie.videoUrl && videoRef.current) {
      videoRef.current.load();
    }
  }, [movie?.status, movie?.videoUrl]);

  if (loadingMovie) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
        </div>
      </Layout>
    );
  }

  if (movieError || !movie) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
          <AlertCircle className="w-16 h-16 text-destructive mb-4" />
          <h1 className="text-2xl font-bold font-display mb-2">Movie Not Found</h1>
          <p className="text-muted-foreground">The movie you are looking for does not exist or has been removed.</p>
        </div>
      </Layout>
    );
  }

  const steps = [
    { key: "pending", label: "Scripting", icon: Film },
    { key: "processing", label: "Generating Scenes", icon: ImageIcon },
    { key: "rendering", label: "Final Cut", icon: Mic }, // Assuming voice/render happen here
    { key: "completed", label: "Ready", icon: CheckCircle2 },
  ];

  const currentStepIndex = steps.findIndex(s => s.key === movie.status) === -1 
    ? (movie.status === "failed" ? -1 : 1) // Default to processing if status unknown
    : steps.findIndex(s => s.key === movie.status);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        
        {/* Header */}
        <div className="mb-8">
            <h1 className="font-display text-3xl md:text-5xl font-bold mb-4 leading-tight">
              {movie.prompt}
            </h1>
            
            {/* Status Progress */}
            {movie.status !== "failed" && (
              <div className="flex items-center gap-4 text-sm font-medium overflow-x-auto pb-2">
                {steps.map((step, idx) => {
                  const isActive = idx === currentStepIndex;
                  const isCompleted = currentStepIndex > idx || movie.status === "completed";
                  
                  return (
                    <div 
                      key={step.key} 
                      className={cn(
                        "flex items-center gap-2 whitespace-nowrap px-3 py-1.5 rounded-full border transition-all duration-300",
                        isActive ? "bg-primary/20 border-primary text-primary animate-pulse" : 
                        isCompleted ? "bg-white/10 border-transparent text-white" : 
                        "text-muted-foreground border-transparent opacity-50"
                      )}
                    >
                      <step.icon className="w-4 h-4" />
                      {step.label}
                    </div>
                  );
                })}
              </div>
            )}
            
            {movie.status === "failed" && (
                <div className="flex items-center gap-2 text-destructive bg-destructive/10 p-4 rounded-xl border border-destructive/20 mt-4">
                    <AlertCircle className="w-5 h-5" />
                    <span>Production Failed: {movie.error || "An unknown error occurred during generation."}</span>
                </div>
            )}
        </div>

        {/* Main Content: Video Player or Loading State */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column: Player / Preview */}
          <div className="lg:col-span-2 space-y-6">
            <div className="aspect-video bg-black rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative group">
              {movie.status === "completed" && movie.videoUrl ? (
                <video 
                  ref={videoRef}
                  controls 
                  className="w-full h-full object-cover"
                  src={movie.videoUrl}
                  poster={scenes?.[0]?.imageUrl || undefined}
                >
                  Your browser does not support the video tag.
                </video>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8 bg-card/50 backdrop-blur-sm">
                   <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6 relative">
                      <RefreshCw className="w-8 h-8 text-primary animate-spin" />
                      <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-ping opacity-20" />
                   </div>
                   <h3 className="text-xl font-bold mb-2">Production in Progress</h3>
                   <p className="text-muted-foreground max-w-sm">
                     AI is currently visualizing your scenes. This usually takes 2-3 minutes. The video will appear here automatically.
                   </p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Scene List */}
          <div className="lg:col-span-1">
            <div className="bg-card border border-white/5 rounded-2xl p-6 h-[600px] flex flex-col">
              <h3 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-primary" />
                Script & Scenes
              </h3>
              
              <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
                {scenes && scenes.length > 0 ? (
                  <AnimatePresence>
                    {scenes.sort((a,b) => a.order - b.order).map((scene, idx) => (
                      <motion.div 
                        key={scene.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="bg-black/40 rounded-xl p-3 border border-white/5 hover:border-primary/30 transition-colors"
                      >
                        <div className="flex gap-3">
                          <div className="w-20 h-20 bg-black/60 rounded-lg flex-shrink-0 overflow-hidden relative">
                             {scene.imageUrl ? (
                               <img src={scene.imageUrl} alt={`Scene ${idx+1}`} className="w-full h-full object-cover" />
                             ) : (
                               <div className="w-full h-full flex items-center justify-center">
                                 <Loader2 className="w-5 h-5 text-muted-foreground animate-spin" />
                               </div>
                             )}
                             <div className="absolute top-1 left-1 bg-black/60 px-1.5 py-0.5 rounded text-[10px] font-bold">
                               {idx + 1}
                             </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">
                              Narration
                            </p>
                            <p className="text-sm text-gray-300 line-clamp-3 leading-relaxed">
                              {scene.narration}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                ) : (
                   <div className="flex flex-col items-center justify-center h-full text-muted-foreground text-sm">
                      <p>Waiting for script...</p>
                   </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
