import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { Film } from "lucide-react";

export default function NotFound() {
  return (
    <Layout>
      <div className="min-h-[80vh] flex flex-col items-center justify-center w-full">
        <div className="mb-8 p-6 bg-primary/10 rounded-full animate-pulse">
            <Film className="h-16 w-16 text-primary" />
        </div>
        <h1 className="text-4xl font-display font-bold mb-4">404 Scene Not Found</h1>
        <p className="text-xl text-muted-foreground mb-8 text-center max-w-md">
          This scene didn't make the final cut. Let's get you back to the main set.
        </p>

        <Link href="/" className="px-8 py-3 rounded-xl bg-white text-black font-bold hover:bg-gray-200 transition-colors">
          Return to Studio
        </Link>
      </div>
    </Layout>
  );
}
