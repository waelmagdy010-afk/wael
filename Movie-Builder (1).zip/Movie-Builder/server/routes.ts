import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { generateScript } from "./lib/openai";
import { generateImage } from "./lib/vertex";
import { generateVoice } from "./lib/voice";
import { createSceneVideo, mergeVideos } from "./lib/ffmpeg";
import { z } from "zod";
import path from "path";
import fs from "fs";

// Ensure tmp directories exist
const TMP_DIR = "/tmp/movie-generator";
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

async function processMovie(movieId: number) {
  try {
    const movie = await storage.getMovie(movieId);
    if (!movie) return;

    // 1. Scripting
    await storage.updateMovie(movieId, { status: "scripting" });
    const script = await generateScript(movie.prompt);
    
    // Save scenes
    for (const sceneData of script) {
      await storage.createScene({
        movieId,
        order: sceneData.order,
        narration: sceneData.narration,
        imagePrompt: sceneData.imagePrompt,
        status: "pending"
      });
    }
    
    await storage.updateMovie(movieId, { 
      script: script, 
      status: "generating_media" 
    });

    // 2. Media Generation
    const scenes = await storage.getScenes(movieId);
    const videoPaths: string[] = [];

    for (const scene of scenes) {
      const baseName = `movie_${movieId}_scene_${scene.order}`;
      const imagePath = path.join(TMP_DIR, `${baseName}.png`); // Vertex typically outputs png or jpg
      const audioPath = path.join(TMP_DIR, `${baseName}.mp3`);
      const videoPath = path.join(TMP_DIR, `${baseName}.mp4`);

      // Generate Image
      await generateImage(scene.imagePrompt, imagePath);
      await storage.updateScene(scene.id, { imageUrl: `/api/assets/${path.basename(imagePath)}` });

      // Generate Voice
      await generateVoice(scene.narration, audioPath);
      await storage.updateScene(scene.id, { audioUrl: `/api/assets/${path.basename(audioPath)}` });

      // Generate Scene Video
      await createSceneVideo(imagePath, audioPath, videoPath);
      await storage.updateScene(scene.id, { 
        videoUrl: `/api/assets/${path.basename(videoPath)}`,
        status: "completed" 
      });

      videoPaths.push(videoPath);
    }

    // 3. Rendering Final Movie
    await storage.updateMovie(movieId, { status: "rendering" });
    const finalVideoPath = path.join(TMP_DIR, `movie_${movieId}_final.mp4`);
    await mergeVideos(videoPaths, finalVideoPath);

    await storage.updateMovie(movieId, { 
      status: "completed",
      videoUrl: `/api/assets/${path.basename(finalVideoPath)}`
    });

  } catch (error: any) {
    console.error(`Error processing movie ${movieId}:`, error);
    await storage.updateMovie(movieId, { 
      status: "failed", 
      error: error.message || "Unknown error" 
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Serve generated assets from /tmp
  app.use('/api/assets', (req, res) => {
    const filename = req.path.substring(1); // remove leading slash
    const filepath = path.join(TMP_DIR, filename);
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.status(404).send('Not found');
    }
  });

  app.post(api.movies.create.path, async (req, res) => {
    try {
      const input = api.movies.create.input.parse(req.body);
      const movie = await storage.createMovie(input);
      
      // Trigger background processing
      processMovie(movie.id);
      
      res.status(201).json(movie);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get(api.movies.list.path, async (req, res) => {
    const movies = await storage.listMovies();
    res.json(movies);
  });

  app.get(api.movies.get.path, async (req, res) => {
    const movie = await storage.getMovie(Number(req.params.id));
    if (!movie) return res.status(404).json({ message: "Movie not found" });
    res.json(movie);
  });

  app.get(api.movies.getScenes.path, async (req, res) => {
    const scenes = await storage.getScenes(Number(req.params.id));
    res.json(scenes);
  });

  return httpServer;
}
