import { db } from "./db";
import { movies, scenes, type InsertMovie, type Movie, type Scene } from "@shared/schema";
import { eq, asc } from "drizzle-orm";

export interface IStorage {
  createMovie(movie: InsertMovie): Promise<Movie>;
  getMovie(id: number): Promise<Movie | undefined>;
  listMovies(): Promise<Movie[]>;
  updateMovie(id: number, updates: Partial<Movie>): Promise<Movie>;
  
  createScene(scene: typeof scenes.$inferInsert): Promise<Scene>;
  getScenes(movieId: number): Promise<Scene[]>;
  updateScene(id: number, updates: Partial<Scene>): Promise<Scene>;
}

export class DatabaseStorage implements IStorage {
  async createMovie(insertMovie: InsertMovie): Promise<Movie> {
    const [movie] = await db.insert(movies).values(insertMovie).returning();
    return movie;
  }

  async getMovie(id: number): Promise<Movie | undefined> {
    const [movie] = await db.select().from(movies).where(eq(movies.id, id));
    return movie;
  }

  async listMovies(): Promise<Movie[]> {
    return await db.select().from(movies).orderBy(asc(movies.createdAt));
  }

  async updateMovie(id: number, updates: Partial<Movie>): Promise<Movie> {
    const [updated] = await db.update(movies)
      .set(updates)
      .where(eq(movies.id, id))
      .returning();
    return updated;
  }

  async createScene(scene: typeof scenes.$inferInsert): Promise<Scene> {
    const [newScene] = await db.insert(scenes).values(scene).returning();
    return newScene;
  }

  async getScenes(movieId: number): Promise<Scene[]> {
    return await db.select().from(scenes)
      .where(eq(scenes.movieId, movieId))
      .orderBy(asc(scenes.order));
  }

  async updateScene(id: number, updates: Partial<Scene>): Promise<Scene> {
    const [updated] = await db.update(scenes)
      .set(updates)
      .where(eq(scenes.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
