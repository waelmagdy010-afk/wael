import ffmpeg from 'fluent-ffmpeg';
import path from 'path';

export async function createSceneVideo(
  imagePath: string,
  audioPath: string,
  outputPath: string
): Promise<void> {
  return new Promise((resolve, reject) => {
    // If input files don't exist (mock mode), skip or fail
    // For robustness, we check:
    // ...

    ffmpeg()
      .input(imagePath)
      .loop() // Loop the image
      .input(audioPath)
      .outputOptions([
        '-c:v libx264',
        '-tune stillimage',
        '-c:a aac',
        '-b:a 192k',
        '-pix_fmt yuv420p',
        '-shortest', // Stop when audio ends
      ])
      .save(outputPath)
      .on('end', () => {
        console.log(`Scene created: ${outputPath}`);
        resolve();
      })
      .on('error', (err) => {
        console.error('FFmpeg error (scene):', err);
        reject(err);
      });
  });
}

export async function mergeVideos(
  videoPaths: string[],
  outputPath: string
): Promise<void> {
  if (videoPaths.length === 0) return;

  return new Promise((resolve, reject) => {
    const command = ffmpeg();
    
    videoPaths.forEach((vp) => {
      command.input(vp);
    });

    command
      .on('end', () => {
        console.log(`Movie merged: ${outputPath}`);
        resolve();
      })
      .on('error', (err) => {
        console.error('FFmpeg error (merge):', err);
        reject(err);
      })
      .mergeToFile(outputPath, path.dirname(outputPath)); // temp path for merge
  });
}
