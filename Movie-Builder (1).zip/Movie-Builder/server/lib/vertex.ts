import fs from 'fs';
import path from 'path';
import { PredictionServiceClient, helpers } from '@google-cloud/aiplatform';

// Assume key.json is in the root or config
const KEY_PATH = path.resolve('key.json');
const PROJECT_ID = process.env.GOOGLE_CLOUD_PROJECT || 'my-project';
const LOCATION = 'us-central1';

// Initialize client if key exists
let client: PredictionServiceClient | null = null;

if (fs.existsSync(KEY_PATH)) {
  try {
    const keyFile = JSON.parse(fs.readFileSync(KEY_PATH, 'utf-8'));
    // Basic check if it looks like a real service account key
    if (keyFile.project_id && keyFile.project_id !== 'your-project-id') {
      client = new PredictionServiceClient({
        keyFilename: KEY_PATH,
        apiEndpoint: `${LOCATION}-aiplatform.googleapis.com`,
      });
      console.log("Vertex AI Client Initialized");
    } else {
        console.warn("key.json appears to be a placeholder. Using Mock mode.");
    }
  } catch (error) {
    console.error("Failed to initialize Vertex AI client:", error);
  }
} else {
  console.warn("key.json not found. Vertex AI generation will use mock data.");
}

export async function generateImage(prompt: string, outputPath: string): Promise<void> {
  if (!client) {
    console.log(`[MOCK] Generating image for prompt: "${prompt}" -> ${outputPath}`);
    // Write a 1x1 black PNG to avoid ffmpeg errors
    const base64Png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
    fs.writeFileSync(outputPath, Buffer.from(base64Png, 'base64'));
    return;
  }

  // Real implementation using Imagen 3
  const endpoint = `projects/${PROJECT_ID}/locations/${LOCATION}/publishers/google/models/imagegeneration@006`; // Example model ID
  
  const parameters = helpers.toValue({
    sampleCount: 1,
    aspectRatio: "1:1",
    safetySetting: "block_some",
    personGeneration: "allow_adult",
  });

  const instances = [helpers.toValue({ prompt })];

  const [response] = await client.predict({
    endpoint,
    instances: instances as any, // Type cast for simplicity
    parameters: parameters as any,
  });

  const predictions = response.predictions;
  if (!predictions || predictions.length === 0) {
    throw new Error('No image generated');
  }

  const prediction = predictions[0];
  // Parse response (structure depends on model version)
  // Typically base64 string in bytesBase64Encoded
  const bytesBase64Encoded = prediction.structValue?.fields?.bytesBase64Encoded?.stringValue;
  
  if (bytesBase64Encoded) {
    const buffer = Buffer.from(bytesBase64Encoded, 'base64');
    fs.writeFileSync(outputPath, buffer);
  } else {
    throw new Error('Unexpected response format from Vertex AI');
  }
}
