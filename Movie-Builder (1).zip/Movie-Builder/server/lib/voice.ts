import axios from 'axios';
import fs from 'fs';

const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY;
const VOICE_ID = '21m00Tcm4TlvDq8ikWAM'; // Example Voice ID (Rachel)

export async function generateVoice(text: string, outputPath: string): Promise<void> {
  if (!ELEVENLABS_API_KEY) {
    console.log(`[MOCK] Generating voice for: "${text}" -> ${outputPath}`);
    // Mock: Write a tiny valid MP3 (silence) to avoid ffmpeg errors
    // Minimal MP3 frame (MPEG 2.5 Layer 3 8kbps 8kHz) - this is just a dummy sequence
    // Using a valid hex sequence for a short silent MP3 frame would be better.
    // This is a minimal valid MP3 header + some data.
    const dummyMp3Base64 = "SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4LjI5LjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAEAAABIADAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDATGF2YzU4LjU0AAAAAAAAAAAAAAAAJAAAAAAAAAAAASCCQAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAA=";
    fs.writeFileSync(outputPath, Buffer.from(dummyMp3Base64, 'base64'));
    return;
  }

  try {
    const response = await axios.post(
      `https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}`,
      {
        text,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5,
        },
      },
      {
        headers: {
          'Accept': 'audio/mpeg',
          'xi-api-key': ELEVENLABS_API_KEY,
          'Content-Type': 'application/json',
        },
        responseType: 'arraybuffer',
      }
    );

    fs.writeFileSync(outputPath, Buffer.from(response.data));
  } catch (error) {
    console.error('ElevenLabs API Error:', error);
    throw new Error('Failed to generate voice');
  }
}
