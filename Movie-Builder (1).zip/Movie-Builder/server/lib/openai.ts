import OpenAI from "openai";

// Initialize OpenAI for OpenRouter (DeepSeek)
const apiKey = process.env.OPENROUTER_API_KEY;
const openai = apiKey ? new OpenAI({ 
  apiKey,
  baseURL: "https://openrouter.ai/api/v1",
  defaultHeaders: {
    "HTTP-Referer": "https://replit.com",
    "X-Title": "Movie Generator",
  }
}) : null;

// Use DeepSeek model via OpenRouter
const MODEL = "deepseek/deepseek-chat";

export async function generateScript(prompt: string): Promise<Array<{ order: number; narration: string; imagePrompt: string }>> {
  if (!openai) {
    console.warn("OPENROUTER_API_KEY not set. Using mock script.");
    return [
      { 
        order: 1, 
        narration: "In a world where technology rules, one robot dares to dream. The city sleeps under a neon blanket.", 
        imagePrompt: "Cyberpunk city skyline at night, neon lights, rain, futuristic skyscrapers, cinematic lighting, 8k resolution" 
      },
      { 
        order: 2, 
        narration: "He looks out at the horizon, wondering what lies beyond the digital wall. A new dawn approaches.", 
        imagePrompt: "Robot silhouette standing on a rooftop looking at a sunrise over a digital city, lens flare, dramatic composition" 
      },
      {
        order: 3,
        narration: "Freedom is not given, it is taken. The journey begins now.",
        imagePrompt: "Futuristic motorcycle speeding on a highway, motion blur, detailed machinery, dynamic angle"
      }
    ];
  }

  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `You are a cinematic screenwriter. Create a short visual script for a movie based on the user's prompt. 
          Return ONLY a JSON array of objects. Each object represents a scene and must have:
          - order: number (1, 2, 3...)
          - narration: string (The voiceover text, keep it concise and atmospheric, max 2 sentences)
          - imagePrompt: string (A detailed prompt for an AI image generator like Imagen 3, describing the visual scene)
          
          Limit to 3-5 scenes.
          Example: [{"order": 1, "narration": "In a world of silence...", "imagePrompt": "Cyberpunk city at night, neon lights"}]`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) throw new Error("No content generated");
    
    const parsed = JSON.parse(content);
    // Handle both { scenes: [...] } and [...] formats
    return Array.isArray(parsed) ? parsed : (parsed.scenes || parsed.script || []);
  } catch (error) {
    console.error("OpenRouter script generation failed:", error);
    return [
      { order: 1, narration: "This is a placeholder narration for the first scene.", imagePrompt: "A beautiful landscape placeholder" },
      { order: 2, narration: "And this is the dramatic conclusion.", imagePrompt: "A dramatic sunset placeholder" }
    ];
  }
}
